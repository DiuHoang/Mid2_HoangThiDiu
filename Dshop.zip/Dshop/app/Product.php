<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //
    protected $table = 'products';
    protected $fillable = ['name', 'id_type', 'description', 'unit_price','promotion_price', 'image', 'unit'];

    public function type_products(){
    	return $this->belongsTo('App\TypeProduct','id_type','id');
    }

    public function bill_details(){
        return $this->hasMany('App\BillDetail', 'id_product', 'id');
    }
}
