<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use App\Slide;
use App\Product;
use App\TypeProduct;
use Session;
use App\Cart;
use App\Bill;
use App\BillDetail;
use App\Customer;
use App\User;
use Hash;
use Auth;
class PageController extends Controller
{
    //
    public function getIndex(){
        $slide = Slide::all();
        $new_product = Product::where('unit', 1)->paginate(8);
        $sanpham_khuyenmai = Product::where('promotion_price', '<>', 0)->paginate(4);
        return view('page.trangchu', compact('slide', 'new_product', 'sanpham_khuyenmai'));
    }

    public function getLoaiSp($type){
        //lay san pham hien thi theo loai

        $sp_theoloai = Product::where('id_type',$type)->limit(3)->get();

        //lay san pham hien thi khac loai
        $sp_khac = Product::where('id_type','<>',$type)->limit(3)->get();

        //lay sn pham hien thi theo loai TypeProduct cho menu ben trai
        $loai = TypeProduct::all();

        //lay ten loai san pham moi khi chung ta chon danh muc loai san pham(phan menu ben trai)
        $loap_sp = TypeProduct::where('id',$type)->first();

    	return view('page.loai_sanpham',compact('sp_theoloai','sp_khac','loai','loap_sp'));
    }

    public function getChitiet(Request $request){
        $sanpham = Product::where('id', $request->id)->first();

        $sp_tuongtu = Product::where('id_type', $sanpham->id_type)->paginate(3);

        $sp_banchay = Product::where('promotion_price', '=', 0)->paginate(3);
        $sp_new = Product::select('id', 'name', 'id_type', 'description', 'unit_price', 'promotion_price', 'image', 'unit', 'created_at', 'updated_at')->where('unit', '>', 0)->orderby('updated_at', 'ASC')->paginate(3);
        return view('page.chitiet_sanpham', compact('sanpham', 'sp_tuongtu', 'sp_banchay', 'sp_new'));
    }

    public function getAddtoCart(Request $request, $id){
        $product = Product::find($id);
        $oldCart = Session('cart')?Session::get('cart'):null;
        $cart = new Cart($oldCart);
        $cart->add($product, $id);
        $request->session()->put('cart',$cart);
        return redirect()->back();
    }

    public function getDelItemCart($id){
        $oldCart = Session::has('cart')?Session::get('cart'):null;
        $cart = new Cart($oldCart);
        $cart->removeItem($id);
        if(count($cart->items) > 0){
            Session::put('cart', $cart);
        }
        else{
            Session::forget('cart');
        }
        return redirect()->back();
    }

    public function getCheckout(){
        return view('page.dathang');
    }

    public function postCheckout(Request $request){
        $cart = Session::get('cart');

        $customer = new Customer;
        $customer->name = $request->name;
        $customer->gender = $request->gender;
        $customer->email = $request->email;
        $customer->address = $request->address;
        $customer->phone_number = $request->phone;
        $customer->note = $request->notes;
        $customer->save();

        $bill = new Bill;
        $bill->id_customer = $customer->id;
        $bill->date_order = date('Y-m-d');
        $bill->total = $cart->totalPrice;
        $bill->payment = $request->payment_method;
        $bill->note = $request->notes;
        $bill->save();

        foreach ($cart->items as $key => $value) {
            $bill_detail = new BillDetail;
            $bill_detail->id_product = $key;
            $bill_detail->id_bill = $bill->id;
            $bill_detail->quanity = $value['qty'];
            $bill_detail->unit_price = ($value['price']/$value['qty']);
            $bill_detail->save();
        }
        Session::forget('cart');
        return redirect()->back()->with('dh_thanhcong','Đặt hàng thành công');

    }

    public function getSignin(){
        return view('page.dangki');
    }

    public function postSignin(Request $request){
        $this->validate($request,
            [
                'email'=>'required|email|unique:users,email',
                'password'=>'required|min:6|max:20',
                'fullname'=>'required',
                're_password'=>'required|same:password'
            ],
            [
                'email.required'=>'Vui lòng nhập email',
                'email.email'=>'Không đúng định dạng email',
                'email.unique'=>'Email đã có người sử dụng',
                'password.required'=>'Vui lòng nhập mật khẩu',
                're_password.same'=>'Mật khẩu không giống nhau',
                'password.min'=>'Mật khẩu ít nhất 6 kí tự'
            ]);
        $user = new User();
        $user->full_name = $request->fullname;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->remember_token = $request->re_password;
        $user->save();
        return redirect()->back()->with('thanhcong','Tạo tài khoản thành công');
    }

    public function getLogin(){
        return view('page.dangnhap');
    }

    public function postLogin(Request $request){
        $this->validate($request,
            [
                'email'=>'required|email',
                'password'=>'required|min:6|max:20'
            ],
            [
                'email.required'=>'Vui lòng nhập email',
                'email.email'=>'Email không đúng định dạng',
                'password.required'=>'Vui lòng nhập mật khẩu',
                'password.min'=>'Mật khẩu ít nhất 6 kí tự',
                'password.max'=>'Mật khẩu không quá 20 kí tự'
            ]
        );
        $user = User::where('email', '=', $request->email )->first();
        if (Hash::check($request->password, $user->password)) {
            Session::put('checkLogin','true');
            return $this->getIndex();
        }else{
            Session::put('checkLogin','fail');
            return redirect()->back()->with(['flag'=>'danger','message'=>'Đăng nhập không thành công']);
        }  
    }
    // public function getLienhe(){
    //     return view('page.lienhe');
    // }

    // public function getAbout(){
    //     return view('page.about');
    // }
}