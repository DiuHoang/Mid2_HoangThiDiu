<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\TypeProduct;
class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $faker = Faker\Factory::create();

        $limit = 12;
        $typeProduct = TypeProduct::all()->pluck('id')->toArray();
        for ($i = 0; $i < $limit; $i++) {
            DB::table('products')->insert([
                'name'=> $faker->name,
                'id_type'=> $faker->randomElement($typeProduct),
                'description'=>$faker->text,
                'unit_price'=>$faker->randomDigit,
                'promotion_price'=>$faker->randomDigit,
                'image'=>($i + 1).'.jpg',
                'unit'=>$faker->boolean(),
                'created_at'=> new DateTime(),
                'updated_at'=> new DateTime()
            ]);
        }
    }
}
