<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\TypeProduct;
class TypeProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $faker = Faker\Factory::create();

        $limit = 12;
        

        for ($i = 0; $i < $limit; $i++) {
            DB::table('type_products')->insert([
                'name'=> $faker->name,
                'description'=>$faker->text,
                'image'=>($i + 1).'.jpg',
                'created_at'=> new DateTime(),
                'updated_at'=> new DateTime()
            ]);
        }
    }
}
