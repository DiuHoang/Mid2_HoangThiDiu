<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login-Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<body>
    <form action="" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="exampleInputUsername">Email</label>
        <input type="text" class="form-control" id="exampleInputUsername" name="email" placeholder="Enter Email">
    </div>
    <div class="form-group">
        <label for="exampleInputPassword">Password</label>
        <input type="password" class="form-control" id="exampleInputPassword" name="password" placeholder="Password">
    </div>
    <div>
        <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>    
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\online_web\resources\views/loginForm.blade.php ENDPATH**/ ?>