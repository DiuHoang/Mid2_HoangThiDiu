<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<body>
    <button type="button" class="btn btn-primary">Hoang Thi Diu - PNV21B</button>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\online_web\resources\views/HoangDiu.blade.php ENDPATH**/ ?>