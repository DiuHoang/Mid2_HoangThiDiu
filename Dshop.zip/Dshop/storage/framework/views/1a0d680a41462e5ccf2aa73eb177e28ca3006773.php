<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="Description" content="Enter your description here"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
<link rel="stylesheet" href="assets/css/style.css">
<title>Signup Form</title>
</head>
<body>
<h3>Form Đăng Kí</h3>
    <form action='' method="post" style="width: 600px;" >
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Enter Name</label>
            <input type="text" class="form-control" name="name" placeholder="Name">
        </div>
        <div class="form-group">
            <label>Enter Age</label>
            <input type="text" class="form-control" name="age" placeholder="Age">
        </div>
        <div class="form-group">
            <label>Enter Date</label>
            <input type="date" class="form-control" name="date" >
        </div>
        <div class="form-group">
            <label>Enter Phone</label>
            <input type="text" class="form-control" name="phone" placeholder="Phone Number">
        </div>
        <div class="form-group">
            <label>Enter Email</label>
            <input type="email" class="form-control" name="email" placeholder="Email">
        </div>
        <div class="form-group">
            <label>Enter Address</label>
            <input type="text" class="form-control" name="address" placeholder="Address">
        </div>
        <div>
            <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <button type="submit" class="btn btn-primary" style="left: 200px;" >Sign Up</button>
        <div >
            <h3>Your Information</h3>
            <?php if(isset($users)): ?>
                <p>Name: <?php echo e($users['name']); ?></p>
                <p>Age: <?php echo e($users['age']); ?></p>
                <p>Date: <?php echo e($users['date']); ?></p>
                <p>Phone: <?php echo e($users['phone']); ?></p>
                <p>Email: <?php echo e($users['email']); ?></p>
                <p>Address: <?php echo e($users['address']); ?></p>
            <?php endif; ?>
        </div>
       
    </form>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\online_web\resources\views/Signup.blade.php ENDPATH**/ ?>