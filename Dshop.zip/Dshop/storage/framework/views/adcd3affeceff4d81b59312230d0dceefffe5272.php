<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel</title>
    <link rel="stylesheet" type="text/css" href="Style/showRoom.css"> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
</head>
<body>
<?php echo csrf_field(); ?>
    <div class="div-header">
        <a href="#" >Trang Chủ</a>
        <a href="#" >Phòng & Mức Giá</a>
        <a href="roomAdd" >Thêm Phòng</a>
        <a href="#" >Hình Ảnh</a>
        <a href="#" >Giới Thiệu</a>
        <a href="#" >Liên Hệ</a>
    </div>
    <form>
        <div class="div-content">
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="div-item">
            <img class="div-content-item" src="<?php echo e($row['image']); ?>" width="300" height="150px">
            <p class="div-content-item" style="font-weight: bold; font-size: 20px"><?php echo e($row->name); ?></p>
            <div class="div-item-flex">
                <h6>Phòng</h6>
                <h6 class="div-content-item"><?php echo e($row->typerooom); ?></h6>
            </div>
            <hr>
            <div class="div-item-flex">
                <h6>Chổ Nghỉ:</h6>
                <h6 class="div-content-item"><?php echo e($row->number); ?> Người</h6p>
            </div>
            <hr>
            <div class="div-item-flex">
                <h6>Kích Thước</h6>
                <h6 class="div-content-item"><?php echo e($row->area); ?></h6>
            </div>
            <hr>
            <div class="div-item-flex">
                <h6>Giá Phòng</h6>
                <h6 class="div-content-item"><?php echo e($row->price); ?> VNĐ</h6>
            </div>
            <hr>
            <div class="div-item-flex">
                <h6>Xem</h6>
                <h6 style="color: burlywood;">Đặt Phòng</h6>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\KT.HoangThiDiu\resources\views/showRoom.blade.php ENDPATH**/ ?>