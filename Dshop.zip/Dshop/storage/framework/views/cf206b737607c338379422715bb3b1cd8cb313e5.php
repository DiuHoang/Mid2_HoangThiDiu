<!DOCTYPE html>
<html>
<head>
	<title>News</title>
    <style></style>
    <link rel="stylesheet" type="text/css" href="Style/news.css"> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

</head>
<body>
    <center>
	<h3>Edit Form</h3>
		
		<form method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
		    <br><br>
		   
		    <input type="file" name="myFile" value="<?php echo e($rooms['image']); ?>" id="myFile">
	    	<br><br>
		    <button type="submit" class="btn btn-primary" name="submit">Submit</button>
		</form>
		<div>
        	<?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    	</div>
    </center>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\KT.HoangThiDiu\resources\views/roomEdit.blade.php ENDPATH**/ ?>